# v10 用户授权：逐步解除硬拒绝，尽可能合并，Astra ultra监督到06:00

用户原话（覆盖旧v09保守门槛，不是旧窗口恢复）：
“其中放开硬规则2，4，6。我们逐步放开限制尽可能的去合并，大胆试错积累经验。同样用astra监督推进到6am”

## 绝对边界
- 新窗口：2026-11-03 00:04后至 **2026-11-03 06:00 JST**。05:15停止启动新单元，05:35数值止，05:40模型收尾，05:42起独立最终验收。截止是今天早上，不是旧11月2日16:00。
- W=/home/u00134/3dgs_line/line_kernel_relaxed_guards_v10；branch=line-kernel-relaxed-guards-v10；ONLY writable source=/home/u00134/3dgs_line/line_kernel_relaxed_guards_v10/reproduction/line_kernel_relaxed_guards_v10、W/docs/line_kernel_relaxed_guards_v10；output=/mnt/hdd1/u00134/radegs_paper_reproduction_v01/line_kernel_relaxed_guards_v10_20261103；runtime=/mnt/hdd1/u00134/radegs_paper_reproduction_v01/line_kernel_relaxed_guards_v10_20261103/orchestration。旧v09及更早所有成果/dirty worktrees/原核输入只读；不push/merge。
- 仅真实gpt-6-astra，model_reasoning_effort="ultra"，原session 01a187da-c1a9-7a91-9a65-91fad4f3e85f。严格串行，无嵌套模型/agents/provider替换。quota/capacity保存后停止，不转模型。
- CPU/BLAS总≤2，无GPU/安装/训练/排队。root≥1GiB/HDD≥10GiB；v10新输出≤20GiB。只查看进程PID/comm，不读取凭据/.env/auth.json/私钥/口令文件，不输出env，不干预其他任务。

## 精确规则编号，不能偷换
对应父级上一条解释：
1 候选/提案：整条曲线2p邻域、端点2p、重叠对应1p等。保留，不擅自改搜索阈值。
2 全成员距离1.5p、有效切向75°的最差成员硬拒绝。**解除硬拒绝**；仍拟合并计算所有成员误差，可软评分、分位数/最差点诊断，不得用inf/隐藏布尔判断重新拒绝。原核不动，不丢掉旧成员。
3 非退化曲线、相邻急折90°、原片段投影弧长单调性。保留现有规则，不擅自一起解除。
4 平行边守卫（重叠≥2p、方向差≤15°、横向间距>0.5p）。**解除硬拒绝**；保留冲突诊断/软代价，明确可能误并并行结构。
5 分叉守卫。保留最新TRANSPORT_BRANCH版本，在同一候选定义内；不要悄悄关闭分叉，也不要继承过时RADIAL门槛作为主臂。
6 自接触、支持最大空隙1.5p、必须新增独特支持等硬拒绝。**解除这些连接硬拒绝**；允许重复观测纯池化/有空隙/自接触的试验性身份合并，保留连续性/空隙/重复支持统计与风险标记。不画辅助桥墨。SUPPORTED_CLOSED仍必须有真实支持证据，不能把解除gap守卫等于自动认证闭环。
数值非有限、无法构造有效曲线、没有任何新成员、数据/事务/安全不变量失败仍不得接受。

## 如何逐步推进（经验优先，不加完美验证门槛）
- 保存严格旧参考及强完整C8/v05。阶段顺序 STRICT → R2 → R2_R4 → R2_R4_R6；每轮真实Astra只读评审先冻结非空决定，再同session实现。第一单元优先真实scan24的旧WHOLE终态，比较严格参考和R2，直/曲及明显竞争邻域都看；不重复旧Ficus科学冒充新成果。
- 下一轮新增一个被授权解除的规则组，保持其它候选/评分/拟合/输入匹配，尽快实际覆盖三个阶段。可选低成本 matched-start 控制用于归因；carry-forward生长另记起点，不把继承归组算新增长。完整旧资产保留，seed/场景子集明确范围。
- 原核几何/协方差/宽度/旋转/opacity/颜色/行序/数量冻结，line_kernel_id→edge_id完整；身份允许整组单调union，旧已接受成员不拆散/丢失，只联合重拟合整条辅助曲线。
- 枚举整条有限曲线附近全部可用片段，给所有合法提案打分，**选择最佳可连接片段且持续重搜**。无8次或其它隐含每种子接受上限，不要求新总分比旧组更低，失败的最近片段不阻止尝试其它。
- “无可连接”只指剩余硬规则/候选定义下穷尽；拟合/算力/枚举预算、模型中断、时钟上限另记。不要因单一局部负例或某个seed停止就宣称整个新授权窗口科学耗尽。坏轮保存原结果，Astra看图定位最早失败，再冻结不同试验；不为做漂亮结果悄悄恢复用户已解除的硬门槛。
- 允许大胆误并试验，不能大胆宣称正确：记录吞并、平行边混入、自交/长无支持桥、单点牵引、巨组比例和最早错误事件。可继续探索更软排序/拟合策略，但新机制需独立冻结，与未改原结果分开，别一夜重做整个框架。

## 输入与真实代码
旧v09完整交付/报告=/mnt/hdd1/u00134/radegs_paper_reproduction_v01/line_kernel_best_fragment_growth_v09_20261102；续接最后数值代码=/mnt/hdd1/u00134/radegs_paper_reproduction_v01/line_kernel_best_fragment_growth_v09_20261102/continuation_001/units/unit_003/source_snapshot；当前旧工作树=/home/u00134/3dgs_line/line_kernel_best_fragment_growth_v09，source reproduction/line_kernel_best_fragment_growth_v09。只读导入时绑定精确SHA，优先已封存snapshot而非裸dirty源码。
scan24最新WHOLE=/mnt/hdd1/u00134/radegs_paper_reproduction_v01/line_kernel_best_fragment_growth_v09_20261102/continuation_001/units/unit_001；scan65最新TRANSPORT=/mnt/hdd1/u00134/radegs_paper_reproduction_v01/line_kernel_best_fragment_growth_v09_20261102/continuation_001/units/unit_003；Ficus=/mnt/hdd1/u00134/radegs_paper_reproduction_v01/line_kernel_best_fragment_growth_v09_20261102/units/unit_001。核验CONFIG/RUN_RESULT和CHECKPOINT解析具体路径，勿猜schema/把scan65 M4写成M5。
完整原线资产 C2L50+05/8BUILD arm C，not原RGB GS中心；原核七数组不变。不得把v07丢了大量已分配成员的自由拆组状态当成当前强基线。

## 必须真实运行的接口
每单元：只读review原字节DECISION → BUILD只写新源码、小型RED/GREEN测试和配置 → RUN_REQUEST → 父持有普通Python数值子进程 → Astra看保存图并写四个分析文件 → seal；严格串行。BUILD不跑完整资产/渲染/后台。
RUN_REQUEST.json fields: script(新source绝对.py),config_path(本unit绝对路径),config_sha256,source_files(新source每一个非pycache文件绝对路径:SHA),helper_files(实际使用旧helper绝对路径:SHA),tests_receipt(本unit真实JSON，returncode:0、tdd_status和原日志路径),max_seconds(int 1..2400)。父仅执行既有venv python -B script --config config。
CONFIG: decision_sha256, unit_root,runtime_root,science_deadline=2026-11-03T05:35:00+09:00; kernel_geometry_frozen:true,final_ink_carrier:original_gaussians,uses_gpu:false,uses_training:false,accepted_merge_is_ground_truth:false,legacy_groups_locked:boolean,membership_policy:monotone_group_union,whole_curve_auxiliary_update:true,stop_policy:until_no_connection_or_supported_closed,relaxed_rule_groups:明确列表（[]/[2]/[2,4]/[2,4,6]）、各实验臂精确policy。DECLARATION不是算法已正确解除证明。
针对新增行为做vertical TDD：逐组开关、已关闭守卫不能隐式否决、旧严格行为匹配、纯重复支持可并、成员全保留、排序/重搜、实际loader guard(phase)、冷载/几何、终止记录；不要重做几十个无关toy证明。RED须真实先失败再最小实现，事后加测试须如实标记。
每次接受先原子保存可冷载成员/辅助曲线/事务与score，再统计/渲染；完整原映射+紧凑delta可重放，避免每步复制原核或全部图。末端完整checkpoint。候选/拟合实际调用数与阶段耗时记录，数据量失控是工程预算停止。

## 看图、经验与交付
每轮输出真实原核全景固定相机同组同色+直/曲隔离组+新增成员+完整竞争背景+最坏巨组/误并；不得只给挑选成功局部图。固定几何意味着重分组不能去旧尖刺；目标是更大且视觉可读的同边身份，不是改几何。保留原图，显示放大注明，无源表面遮挡，无辅助桥墨。
记录接受次数/新UNKNOWN归属/原已分配组union、重复支持池化/内部填充/域外延/最长连续支持/最大gap，按实际起点算，不重复累计。大组或更多assigned不叫准确率。
分析先看少量决定性PNG，**先在前两分钟写REPORT_ZH.md、STATUS.json、NEXT.json、FAILURE_ANALYSIS.json**，再可选扩展。后者含diagnosis_zh,next_change非空，failure_modes非空列表，observed_images实际UNIT相对PNG列表、visual_evidence_missing bool；缺图明确。NEXT action continue|stop + recommended_next_step，别因旧16:00窗口状态stop误停。
每个阶段要指出“放开什么→新接进什么→误并什么→下一步怎么改”的经验。终局报告+真实图+全行映射/原核/辅助模型/源配置的可冷载包；保存负结果和实际EXIT，不伪造物理身份/held-out/时间稳定。
