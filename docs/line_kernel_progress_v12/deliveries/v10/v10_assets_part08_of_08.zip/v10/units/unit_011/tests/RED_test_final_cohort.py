from runtime_io import *
import unittest,tempfile
import test_cohort
ROOT=Path("/mnt/hdd1/u00134/radegs_paper_reproduction_v01/line_kernel_relaxed_guards_v10_20261103/units/unit_011/tests")
class NewSeedsTests(unittest.TestCase):
 def test_real_restore_then_activate_without_mutating_old_union(self):
  try:from final_cohort_loader import load
  except ImportError:from contact_soft_loader import load
  test_cohort.ROOT=ROOT
  with tempfile.TemporaryDirectory(dir=ROOT) as td:
   c,d,o=test_cohort.fixture(Path(td));c.update(raw_seed_ids=[0],restored_origin_ids=[0]);phases=[];z=load(c,phases.append)
   self.assertEqual(z['objects'][2]['seed_origins'],[2]);self.assertEqual(z['objects'][0]['seed_origins'],[0]);self.assertEqual(z['next_version'],21)
   for gid in [0,2]:
    np.testing.assert_array_equal(o[gid]['rows'],z['objects'][gid]['rows']);np.testing.assert_array_equal(o[gid]['q'],z['objects'][gid]['q']);self.assertEqual(o[gid]['version'],z['objects'][gid]['version'])
   self.assertEqual(set(phases),{'readiness'})
   def bad(phase):raise RuntimeError('REAL_GUARD '+phase)
   with self.assertRaisesRegex(RuntimeError,'REAL_GUARD readiness'):load(c,bad)
if __name__=='__main__':unittest.main(verbosity=2)
