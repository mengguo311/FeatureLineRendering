"""Unit010 finite contact-score interface; bounded real numerical fixtures only."""
from runtime_io import *
import unittest,copy,tempfile
import group_fit_core,whole_core
import test_r6
ROOT=Path('/mnt/hdd1/u00134/radegs_paper_reproduction_v01/line_kernel_relaxed_guards_v10_20261103/units/unit_010/tests')

class ContactSoftTests(unittest.TestCase):
 def test_actual_library_has_matched_finite_contact_score_policies(self):
  try:import contact_soft_core as core
  except ImportError:core=group_fit_core
  d,o=test_r6.pooling_fixture();banks=core.libraries(d,o,0,whole_core.CompleteIndex(o))
  self.assertIn('CONTACT_SOFT_J',banks,'existing actual library has no finite CONTACT_SOFT_J policy')
  base=banks['BASE_J'];soft=banks['CONTACT_SOFT_J'];self.assertTrue(base['complete'] and soft['complete'])
  for a,b in zip(base['records'],soft['records']):
   self.assertEqual(a['connectable'],b['connectable'])
   if 'q' in a:np.testing.assert_array_equal(a['q'],b['q'])
   if a['connectable']:
    self.assertAlmostEqual(b['metrics']['score'],a['metrics']['score']+.01*bool(a['metrics']['rule6']['self_contact']))
    self.assertTrue(np.isfinite(b['metrics']['score']))
  self.assertIsNotNone(soft['selected'])

if __name__=='__main__':
 ROOT.mkdir(parents=True,exist_ok=True)
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(ContactSoftTests))
 raise SystemExit(0 if result.wasSuccessful() else 1)
