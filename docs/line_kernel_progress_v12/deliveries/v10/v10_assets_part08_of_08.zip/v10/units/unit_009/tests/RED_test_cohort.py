"""Unit009: actual restricted-loader cohort handoff, with no full-asset execution."""
from runtime_io import *
import unittest,tempfile,copy
import test_scan65,test_loader,test_scan24,test_relaxed
import scan65_loader,group_fit_delivery as delivery
ROOT=Path('/mnt/hdd1/u00134/radegs_paper_reproduction_v01/line_kernel_relaxed_guards_v10_20261103/units/unit_009/tests')

def fixture(r):
 for m in [test_scan65,test_loader,test_scan24,test_relaxed]:m.ROOT=ROOT
 c=test_scan65.m4fixture(r)
 g=json.loads(Path(c['groups']).read_text());g['groups'][2]['supported_length_p']=12.
 Path(c['groups']).write_text(json.dumps(g));c['input_files'][c['groups']]=sha(c['groups'])
 js(r/'raw.json',c);d=scan65_loader.load(c,lambda phase:None);o=copy.deepcopy(d['objects'])
 o[0].update(rows=np.arange(24),leaves=[0,1],q=np.vstack([o[0]['q'],o[1]['q']]),version=20);del o[1]
 delivery.save_stage(r/'accepted',c,d,o,[dict(fixture_event=True)],21,'fixture-binding')
 js(r/'accepted/STOP.json',dict(status='completed',reason='NATURAL_SCOPE_EXHAUSTION'))
 c.update(raw_config=str(r/'raw.json'),restore_stage=str(r/'accepted'),restore_binding='fixture-binding',initial_stage=str(r/'accepted'),initial_next_version=21,restore_seed_ids=[0],restore_seed_versions={'0':20},seed_ids=[2],seed_versions={'2':12},seed_expected_rows={'2':12},tracked_origin_ids=[0,2])
 return c,d,o

class CohortTests(unittest.TestCase):
 def test_actual_loader_keeps_old_composite_and_activates_new_origin(self):
  try:from cohort_loader import load
  except ImportError:from branch_loader import load
  with tempfile.TemporaryDirectory(dir=ROOT) as td:
   r=Path(td);c,d,o=fixture(r);phases=[];z=load(c,phases.append)
   self.assertEqual(z['objects'][0]['seed_origins'],[0]);self.assertEqual(z['objects'][2]['seed_origins'],[2])
   self.assertEqual(z['seed_status'],{2:'READY'});self.assertEqual(z['next_version'],21)
   for gid in [0,2]:
    np.testing.assert_array_equal(z['objects'][gid]['rows'],o[gid]['rows']);np.testing.assert_array_equal(z['objects'][gid]['q'],o[gid]['q']);self.assertEqual(z['objects'][gid]['version'],o[gid]['version'])
   np.testing.assert_array_equal(z['initial_membership']['edge_id'],np.load(r/'accepted/MEMBERSHIP.npz')['edge_id'])
   self.assertEqual(set(phases),{'readiness'})
   def bad(phase):raise RuntimeError('REAL_GUARD '+phase)
   with self.assertRaisesRegex(RuntimeError,'REAL_GUARD readiness'):load(c,bad)

if __name__=='__main__':
 ROOT.mkdir(parents=True,exist_ok=True)
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(CohortTests))
 raise SystemExit(0 if result.wasSuccessful() else 1)
