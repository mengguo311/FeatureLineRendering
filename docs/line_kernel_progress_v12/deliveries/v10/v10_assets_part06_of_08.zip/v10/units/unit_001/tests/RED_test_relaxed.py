from runtime_io import *
import unittest,tempfile,copy
import whole_core as w
from test_whole import synthetic,WholeTests
ROOT=Path('/mnt/hdd1/u00134/radegs_paper_reproduction_v01/line_kernel_relaxed_guards_v10_20261103/units/unit_001/tests')

class RelaxedTests(unittest.TestCase):
 def test_rule2_distance_is_soft_not_hidden_veto(self):
  d,o=synthetic(2);d['asset']['means'][3,1]=2.;q=np.array([[0.,0,0],[4.2,0,0]])
  self.assertEqual(w.evaluate(d,o[0],o[1],q)[1],'member_distance')
  z=w.evaluate(d,o[0],o[1],q,relaxed=[2]);self.assertTrue(z[0],z[1]);self.assertTrue(np.isfinite(z[2]['score']))
  self.assertEqual(z[2]['kernels'],24);self.assertIn(3,z[2]['rule2']['distance_exceed_rows'])
 def test_rule2_angle_is_soft_and_strict_unchanged(self):
  d,o=synthetic(2);d['tangents'][5]=[0.,1.,0];q=np.array([[0.,0,0],[4.2,0,0]])
  self.assertEqual(w.evaluate(d,o[0],o[1],q)[1],'gross_tangent_conflict')
  z=w.evaluate(d,o[0],o[1],q,relaxed=[2]);self.assertTrue(z[0],z[1]);self.assertGreater(z[2]['max_angle_deg'],75);self.assertTrue(np.isfinite(z[2]['score']))
 def test_rule6_pure_pooling_is_allowed_only_when_off(self):
  d,o=synthetic(2);rr=o[1]['rows'];d['asset']['means'][rr]=d['asset']['means'][o[0]['rows']];d['leaves'][1].q=o[0]['q'].copy();o[1]['q']=o[0]['q'].copy();q=o[0]['q'].copy()
  self.assertEqual(w.evaluate(d,o[0],o[1],q)[1],'no_unique_support')
  z=w.evaluate(d,o[0],o[1],q,relaxed=[6]);self.assertTrue(z[0],z[1]);self.assertEqual(z[2]['unique_donor_support_p'],0);self.assertTrue(np.isfinite(z[2]['score']))
 def test_rule4_parallel_is_diagnostic_only_when_off(self):
  d,o=synthetic(2);rr=o[1]['rows'];d['asset']['means'][rr]=np.c_[np.linspace(0,4,12),np.full(12,.8),np.zeros(12)];q1=np.array([[0.,.8,0],[4.,.8,0]]);d['leaves'][1].q=q1;o[1]['q']=q1
  q=np.array([[0.,.4,0],[4.,.4,0]]);self.assertEqual(w.evaluate(d,o[0],o[1],q)[1],'parallel_conflict')
  z=w.evaluate(d,o[0],o[1],q,relaxed=[4]);self.assertTrue(z[0],z[1]);self.assertTrue(z[2]['parallel_conflicts'])
 def test_strict_numerical_parity(self):
  import strict_whole_core as old
  d,o=synthetic(2);q=np.array([[0.,0,0],[4.2,0,0]])
  a=old.evaluate(d,o[0],o[1],q);b=w.evaluate(d,o[0],o[1],q)
  self.assertEqual(a[:2],b[:2]);self.assertEqual(a[2]['score'],b[2]['score']);np.testing.assert_array_equal(a[3],b[3])
 def test_remaining_degeneracy_not_relaxed(self):
  d,o=synthetic(2);q=np.array([[0.,0,0],[2.,0,0],[0.,0,0]])
  self.assertEqual(w.evaluate(d,o[0],o[1],q,relaxed=[2,4,6])[1],'vertex_degeneracy')

if __name__=='__main__':
 ROOT.mkdir(parents=True,exist_ok=True)
 suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromTestCase(k) for k in [RelaxedTests,WholeTests])
 r=unittest.TextTestRunner(verbosity=2).run(suite);raise SystemExit(0 if r.wasSuccessful() else 1)
