"""Unit003 functional changes; inherited regressions are explicitly reused."""
from runtime_io import *
import unittest,tempfile,copy
from unittest.mock import patch
import whole_core as w
from test_whole import synthetic,WholeTests
import test_relaxed
ROOT=Path('/mnt/hdd1/u00134/radegs_paper_reproduction_v01/line_kernel_relaxed_guards_v10_20261103/units/unit_003/tests')
test_relaxed.ROOT=ROOT

def pooling_fixture():
 d,o=synthetic(2);r=o[1]['rows'];d['asset']['means'][r]=d['asset']['means'][o[0]['rows']]
 d['leaves'][1].q=o[0]['q'].copy();o[1]['q']=o[0]['q'].copy()
 d['representatives'].update(member_rows=np.arange(2),member_offsets=np.arange(3))
 return d,o

class R6Tests(unittest.TestCase):
 def test_actual_library_dispatches_pure_pooling(self):
  try:import r6_core as core
  except ImportError:import r4_core as core
  d,o=pooling_fixture();banks=core.libraries(d,o,0,w.CompleteIndex(o))
  self.assertIn('R2_R4_R6_OFF_TRANSPORT',banks,'actual library never dispatches [2,4,6]')
  a=banks['R2_R4_OFF_TRANSPORT'];b=banks['R2_R4_R6_OFF_TRANSPORT']
  self.assertTrue(a['complete'] and b['complete']);self.assertIsNone(a['selected']);self.assertIsNotNone(b['selected'])
  z=b['records'][b['selected']];self.assertEqual(z['relaxed_rule_groups'],[2,4,6]);self.assertEqual(z['metrics']['unique_donor_support_p'],0)
  self.assertTrue(z['metrics']['rule6']['pure_pooling']);self.assertTrue(np.isfinite(z['metrics']['score']));self.assertEqual(z['metrics']['kernels'],24)
  self.assertFalse(any(r['reason'] in ['no_unique_support','unsupported_gap','nonlocal_contact'] for r in b['records']))

 def test_closed_geometry_with_support_gap_accepts_without_closed_stop(self):
  from port_paths import Leaf
  a=np.linspace(0,2*np.pi,65);q=np.c_[2*np.cos(a),2*np.sin(a),np.zeros(len(a))];q[-1]=q[0]
  idx=np.array([1,2,3,61,62,63]);x=q[idx];t=w.project(x,q)[2];rows=np.arange(6)
  leaves={0:Leaf(0,0,rows[:3],np.array([0]),q[:5],True,True,np.array([[0.,.5]])),1:Leaf(1,1,rows[3:],np.array([1]),q[-5:],True,True,np.array([[0.,.5]]))}
  d=dict(p=1.,asset=dict(means=x,covariance=np.tile(np.eye(3)*.04,(6,1,1))),tangents=t,leaves=leaves,representatives=dict(x=x[:2],t=t[:2]))
  g=dict(rows=rows[:3],leaves=[0]);f=dict(rows=rows[3:],leaves=[1])
  self.assertEqual(w.evaluate(d,g,f,q,relaxed=[2,4])[1],'unsupported_gap')
  ok,reason,meta,_=w.evaluate(d,g,f,q,relaxed=[2,4,6]);self.assertTrue(ok,reason)
  self.assertGreater(meta['max_gap_p'],1.5);self.assertTrue(np.isfinite(meta['score']))
  self.assertFalse(meta['closure']['supported'],'gap relaxation falsely certifies supported closure')

if __name__=='__main__':
 ROOT.mkdir(parents=True,exist_ok=True)
 suite=unittest.defaultTestLoader.loadTestsFromTestCase(R6Tests)
 result=unittest.TextTestRunner(verbosity=2).run(suite);raise SystemExit(0 if result.wasSuccessful() else 1)
