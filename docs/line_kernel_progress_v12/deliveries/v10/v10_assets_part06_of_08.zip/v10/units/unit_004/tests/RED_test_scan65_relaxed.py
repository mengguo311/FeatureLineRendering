"""New scan65 integration and relation-accounting tests; core regressions are reused."""
from runtime_io import *
import unittest,tempfile,copy
from unittest.mock import patch
import test_r6,test_relaxed,test_loader,test_scan24,test_scan65
from test_r6 import pooling_fixture
import whole_core as w
ROOT=Path('/mnt/hdd1/u00134/radegs_paper_reproduction_v01/line_kernel_relaxed_guards_v10_20261103/units/unit_004/tests')
for module in [test_r6,test_relaxed,test_loader,test_scan24,test_scan65]:module.ROOT=ROOT

class Scan65RelaxedTests(unittest.TestCase):
 def test_real_library_relation_rows_and_unchanged_choices(self):
  try:import scan65_relaxed_core as core
  except ImportError:import r6_core as core
  import r6_core
  from r6_delivery import scientific
  d,o=pooling_fixture();old=r6_core.libraries(d,o,0,w.CompleteIndex(o));new=core.libraries(d,o,0,w.CompleteIndex(o))
  for policy,b in new.items():
   self.assertIn('relation_diagnostics',b,'same-donor relation evidence missing')
   self.assertEqual(scientific(old[policy]),scientific(b))
   np.testing.assert_array_equal(b['relation_rows']['group_rows'],o[0]['rows'])
   np.testing.assert_array_equal(b['relation_rows']['donor_rows'],o[1]['rows'])
   records=b['relation_diagnostics']['donors'][0]['interpretations']
   self.assertEqual(len(records),len(b['records']))
   for z,r in zip(records,b['records']):
    self.assertEqual(z['selected'],b['selected']==z['record_index'])
    if 'rule6' not in r.get('metrics',{}):self.assertEqual(z['rule6_status'],'NOT_REACHED')
  b=new['R2_R4_R6_OFF_TRANSPORT'];z=b['relation_diagnostics']['donors'][0]['interpretations'][b['selected']]
  self.assertEqual(z['unique_donor_support_p'],0);self.assertAlmostEqual(sum(z['score_terms'].values()),z['score'])

if __name__=='__main__':
 ROOT.mkdir(parents=True,exist_ok=True)
 r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Scan65RelaxedTests));raise SystemExit(0 if r.wasSuccessful() else 1)
