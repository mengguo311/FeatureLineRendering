"""Unit002 tests. Existing core regressions are reused, not newly claimed TDD."""
from runtime_io import *
import unittest,tempfile,copy
from unittest.mock import patch
import relaxed_core
from test_whole import synthetic,WholeTests
import test_relaxed
ROOT=Path('/mnt/hdd1/u00134/radegs_paper_reproduction_v01/line_kernel_relaxed_guards_v10_20261103/units/unit_002/tests')
test_relaxed.ROOT=ROOT

def parallel_fixture():
 d,o=synthetic(2);rr=o[1]['rows'];d['asset']['means'][rr]=np.c_[np.linspace(0,4,12),np.full(12,.8),np.zeros(12)]
 q=np.array([[0.,.8,0],[4.,.8,0]]);d['leaves'][1].q=q.copy();o[1]['q']=q.copy()
 d['representatives'].update(member_rows=np.arange(2),member_offsets=np.arange(3))
 return d,o

class R4Tests(unittest.TestCase):
 def test_actual_policy_dispatch_parallel_candidate_finite(self):
  # Before unit002 implementation this calls the real unit001 library: [2,4] is absent.
  try:import r4_core as core
  except ImportError:core=relaxed_core
  d,o=parallel_fixture();banks=core.libraries(d,o,0,core.base.CompleteIndex(o))
  self.assertIn('R2_R4_OFF_TRANSPORT',banks,'actual library never dispatches [2,4]')
  ctl=banks['R2_OFF_TRANSPORT'];new=banks['R2_R4_OFF_TRANSPORT']
  self.assertTrue(ctl['complete']);self.assertIsNone(ctl['selected']);self.assertTrue(new['complete'])
  self.assertIsNotNone(new['selected'],[r['reason'] for r in new['records']])
  z=new['records'][new['selected']];self.assertEqual(z['relaxed_rule_groups'],[2,4]);self.assertTrue(z['metrics']['parallel_conflicts']);self.assertTrue(np.isfinite(z['metrics']['score']));self.assertEqual(z['metrics']['kernels'],24)
  self.assertFalse(any(r['reason']=='parallel_conflict' for r in new['records']))
  self.assertTrue(any(r['reason']=='parallel_conflict' for r in ctl['records']))

if __name__=='__main__':
 ROOT.mkdir(parents=True,exist_ok=True)
 suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromTestCase(k) for k in [R4Tests,test_relaxed.RelaxedTests,WholeTests])
 result=unittest.TextTestRunner(verbosity=2).run(suite);raise SystemExit(0 if result.wasSuccessful() else 1)
