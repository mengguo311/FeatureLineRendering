"""Unit005 ranking ablation, genuine policy RED/GREEN; inherited regressions reused."""
from runtime_io import *
import unittest,tempfile,copy
from unittest.mock import patch
import test_r6,test_relaxed,test_loader,test_scan24,test_scan65
import whole_core as w
from test_whole import synthetic
ROOT=Path('/mnt/hdd1/u00134/radegs_paper_reproduction_v01/line_kernel_relaxed_guards_v10_20261103/units/unit_005/tests')
for module in [test_r6,test_relaxed,test_loader,test_scan24,test_scan65]:module.ROOT=ROOT

class NoUTests(unittest.TestCase):
 def test_actual_library_only_removes_reward_and_retains_pooling(self):
  try:import no_u_core as core
  except ImportError:import scan65_relaxed_core as core
  for pooling in [False,True]:
   d,o=test_r6.pooling_fixture() if pooling else synthetic(2)
   d['representatives'].update(member_rows=np.arange(2),member_offsets=np.arange(3))
   banks=core.libraries(d,o,0,w.CompleteIndex(o))
   self.assertIn('NO_U_REWARD',banks,'actual catalog has no NO_U_REWARD policy')
   old=banks['R2_R4_R6_OFF_TRANSPORT'];new=banks['NO_U_REWARD'];self.assertTrue(old['complete'] and new['complete']);self.assertIsNotNone(new['selected'])
   for a,b in zip(old['records'],new['records']):
    self.assertEqual(a['reason'],b['reason']);self.assertEqual(a['connectable'],b['connectable'])
    if 'q' in a:np.testing.assert_array_equal(a['q'],b['q'])
    if a['connectable']:
     U=a['metrics']['unique_donor_support_p'];self.assertEqual(b['metrics']['score'],a['metrics']['score']+.25*U/(1+U));self.assertTrue(np.isfinite(b['metrics']['score']));self.assertEqual(b['metrics']['score_original'],a['metrics']['score'])
     if pooling:self.assertEqual(U,0);self.assertEqual(a['metrics']['score'],b['metrics']['score'])
   diag=new['relation_diagnostics']['donors'][0]['interpretations'][new['selected']]
   self.assertEqual(diag['score_terms']['unique_support'],0);self.assertAlmostEqual(sum(diag['score_terms'].values()),diag['score'])

if __name__=='__main__':
 ROOT.mkdir(parents=True,exist_ok=True)
 r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(NoUTests));raise SystemExit(0 if r.wasSuccessful() else 1)
