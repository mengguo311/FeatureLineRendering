"""Unit006 genuine functional score RED/GREEN; inherited tests identified separately."""
from runtime_io import *
import unittest,tempfile,copy
from unittest.mock import patch
import test_no_u,test_r6,test_relaxed,test_loader,test_scan24,test_scan65
import whole_core as w
from test_whole import synthetic
ROOT=Path('/mnt/hdd1/u00134/radegs_paper_reproduction_v01/line_kernel_relaxed_guards_v10_20261103/units/unit_006/tests')
for module in [test_no_u,test_r6,test_relaxed,test_loader,test_scan24,test_scan65]:module.ROOT=ROOT

def unequal_fixture():
 d,o=synthetic(3);d['representatives'].update(member_rows=np.arange(3),member_offsets=np.arange(4))
 o[0].update(rows=np.union1d(o[0]['rows'],o[1]['rows']),leaves=[0,1],q=np.vstack([o[0]['q'],o[1]['q']]))
 del o[1]
 d['asset']['means'][o[2]['rows'],1]=.3
 d['tangents'][o[2]['rows']]=[np.cos(80*np.pi/180),np.sin(80*np.pi/180),0.]
 return d,o

class BalancedTests(unittest.TestCase):
 def test_actual_library_equal_group_weight_not_pooled_mean(self):
  try:import balanced_core as core
  except ImportError:import no_u_core as core
  d,o=unequal_fixture();banks=core.libraries(d,o,0,w.CompleteIndex(o))
  self.assertIn('GROUP_BALANCED_SCORE',banks,'actual catalog has no GROUP_BALANCED_SCORE policy')
  old=banks['NO_U_REWARD'];new=banks['GROUP_BALANCED_SCORE'];self.assertTrue(new['complete']);self.assertIsNotNone(new['selected']);changed=False
  for a,b in zip(old['records'],new['records']):
   self.assertEqual(a['connectable'],b['connectable']);self.assertEqual(a['reason'],b['reason'])
   if 'q' in a:np.testing.assert_array_equal(a['q'],b['q'])
   if not b['connectable']:continue
   Ds=[];Ts=[]
   for gid in [0,b['donor']]:
    rows=o[gid]['rows'];_,dist,tan,_,_=w.project(d['asset']['means'][rows]/d['p'],b['q']);t=d['tangents'][rows];valid=np.isfinite(t).all(1)&(np.linalg.norm(t,axis=1)>w.EPS)
    Ds.append(np.mean(dist**2));Ts.append(np.mean((np.degrees(np.arccos(np.clip(abs(np.sum(t[valid]*tan[valid],1)),0,1)))/90)**2))
   m=b['metrics'];expected=.5*sum(Ds)+.25*np.mean(Ts)+.05*m['turn_mean_square']+.1*m['max_gap_p']**2+.02*len(b['q'])/(m['length_p']+1)
   self.assertAlmostEqual(m['score'],expected,places=12);self.assertEqual(m['score_no_u_reward'],a['metrics']['score']);self.assertTrue(np.isfinite(m['score']));changed|=abs(m['score']-a['metrics']['score'])>1e-8
   self.assertEqual(m['group_balance']['G']['count'],24);self.assertEqual(m['group_balance']['F']['count'],12)
  self.assertTrue(changed)

if __name__=='__main__':
 ROOT.mkdir(parents=True,exist_ok=True)
 r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(BalancedTests));raise SystemExit(0 if r.wasSuccessful() else 1)
