"""Unit007 functional fit-policy RED/GREEN; no full asset execution."""
from runtime_io import *
import unittest,copy,tempfile
from unittest.mock import patch
import test_balanced,test_no_u,test_r6,test_relaxed,test_loader,test_scan24,test_scan65
import whole_core as w
from test_whole import synthetic
ROOT=Path('/mnt/hdd1/u00134/radegs_paper_reproduction_v01/line_kernel_relaxed_guards_v10_20261103/units/unit_007/tests')
for module in [test_balanced,test_no_u,test_r6,test_relaxed,test_loader,test_scan24,test_scan65]:module.ROOT=ROOT

class GroupFitTests(unittest.TestCase):
 def test_actual_library_separate_group_fit(self):
  try:import group_fit_core as core
  except ImportError:import balanced_core as core
  d,o=test_balanced.unequal_fixture();banks=core.libraries(d,o,0,w.CompleteIndex(o))
  self.assertIn('GROUP_BALANCED_FIT',banks,'actual catalog has no GROUP_BALANCED_FIT policy')
  old=banks['GROUP_BALANCED_SCORE'];new=banks['GROUP_BALANCED_FIT'];self.assertTrue(old['complete'] and new['complete'])
  self.assertEqual(old['neighbors'],new['neighbors']);changed=False
  for a,b in zip(old['records'],new['records']):
   if 'q' not in a or 'q' not in b:continue
   np.testing.assert_array_equal(a['template'],b['template']);changed|=not np.array_equal(a['q'],b['q'])
   f=b['fit']['group_weighting'];self.assertEqual(f['G_count'],24);self.assertEqual(f['F_count'],12)
  self.assertTrue(changed,'unequal group weights must change actual fitted Q')

if __name__=='__main__':
 ROOT.mkdir(parents=True,exist_ok=True)
 r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(GroupFitTests));raise SystemExit(0 if r.wasSuccessful() else 1)
