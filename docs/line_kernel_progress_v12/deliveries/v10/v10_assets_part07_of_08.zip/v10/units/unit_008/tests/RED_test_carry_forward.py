"""Unit008 fixed-frame evidence and actual continuation interface tests."""
from runtime_io import *
import unittest, tempfile, copy
import whole_core as whole
ROOT=Path('/mnt/hdd1/u00134/radegs_paper_reproduction_v01/line_kernel_relaxed_guards_v10_20261103/units/unit_008/tests')

class CarryTests(unittest.TestCase):
 def test_fixed_coordinates_keep_rows_clipping_and_original_derivative_width(self):
  try:
   from carry_forward_support import account
  except ImportError:
   def account(d,q,inherited,current):return whole.support(d,current,q)
  q=np.array([[0.,0,0],[2.,0,0]])
  x=np.array([[0.,0,0],[1.,0,0],[2.4,0,0],[1.5,.4,0]])
  d=dict(p=1.,asset=dict(means=x,covariance=np.tile(np.diag([.04,.25,.01]),(4,1,1))),tangents=np.array([[1.,0,0],[0,1.,0],[1.,0,0],[0.,0,0]]))
  before=copy.deepcopy(d);result=account(d,q,np.array([0,1]),np.arange(4))
  self.assertIn('evidence',result,'dynamic support lacks fixed-reference row/extrapolation accounting')
  e=result['evidence'];s=result['summary']
  np.testing.assert_array_equal(e['rows'],np.arange(4));np.testing.assert_array_equal(e['valid'],[True,True,True,False])
  self.assertAlmostEqual(e['half'][1],.5);self.assertAlmostEqual(e['finite_s'][2],2.)
  self.assertAlmostEqual(e['extended_s'][2],2.4);self.assertFalse(e['valid'][3])
  self.assertTrue(e['clipped'][2].any());self.assertEqual(s['sets']['current']['rows'],4)
  self.assertGreater(s['new_minus_inherited_p'],0);self.assertFalse(s['used_for_decision'])
  np.testing.assert_array_equal(d['asset']['means'],before['asset']['means'])
  np.testing.assert_array_equal(q,[[0,0,0],[2,0,0]])

if __name__=='__main__':
 ROOT.mkdir(parents=True,exist_ok=True)
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(CarryTests))
 raise SystemExit(0 if result.wasSuccessful() else 1)
