# 两个独立ZIP

- `scan65_full_position_collapse_model.zip`：完整处理后279616核、完整原版回退、映射、全部3655组模型/账本、原生图、源码与父级验收。可单独加载模型使用。
- `scan65_full_position_collapse_checkpoints.zip`：全部原始事务检查点（unit/group_journal），供完整恢复/复核。

需要所有证据时，将两个ZIP解压到同一目录。它们不是分卷压缩，不要二进制拼接。清单分别叫MANIFEST.json和CHECKPOINTS_MANIFEST.json，不会覆盖。
完整202成员原归档超过保守45MiB传输上限，已保留；科学文件没有删改或降分辨率。
